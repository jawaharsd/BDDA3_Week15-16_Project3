#Jawahar-170004
import pandas as pd
import numpy as np
import matplotlib as plt
from pyspark.ml.clustering import BisectingKMeans
from pyspark.sql import SparkSession
import itertools
from sklearn import mixture
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
from sklearn.decomposition import PCA



spark = SparkSession.builder.appName('Spark').getOrCreate()

# loading data
dataset = spark.read.format("com.databricks.spark.csv").option("header", "true").load("data.csv")

#Sample of 10000 randomly to cut the processing time

data = pd.DataFrame({
   c: np.random.randn(10000) for c in ['Fresh','Milk','Grocery' ,'Frozen','Detergents_Paper','Delicatessen','Region','Channel']
})

data.drop(['Region', 'Channel'], axis = 1, inplace = True)

indices = [43, 12, 39]


samples = pd.DataFrame(data.loc[indices], columns = data.columns).reset_index(drop = True)
print ("Chosen samples of wholesale customers dataset:")
display(samples)

log_data = data
outliers_lst  = []

# For each feature in the list find the data points with extreme high or low values
for feature in log_data.columns:
    # Calculating Q1 i.e 25th percentile of the data for the given feature
    Q1 = np.percentile(log_data.loc[:, feature], 25)

    # Calculating Q3 i.e 75th percentile of the data for the given feature
    Q3 = np.percentile(log_data.loc[:, feature], 75)


    step = 1.5 * (Q3 - Q1)

    # Display the outliers
 
    outliers_rows = log_data.loc[~((log_data[feature] >= Q1 - step) & (log_data[feature] <= Q3 + step)), :]
    # displaying outliers rows

    outliers_lst.append(list(outliers_rows.index))

outliers = list(itertools.chain.from_iterable(outliers_lst))

# Unique outliers

uniq_outliers = list(set(outliers))

# Duplicate outliers
dup_outliers = list(set([x for x in outliers if outliers.count(x) > 1]))


# Removing duplicate outliers

good_data = log_data.drop(log_data.index[dup_outliers]).reset_index(drop = True)



# Processed Data

print ('shape of data before dropping outliers:\n',data.shape)
print ('New shape of data:\n', good_data.shape)

pca = PCA(n_components=2)
pca.fit(good_data)

# Transform the good data using the PCA fit above
reduced_data = pca.transform(good_data)

# Transform the sample log-data using the PCA fit above
pca_samples = pca.transform(samples)

reduced_data = pd.DataFrame(reduced_data, columns = ['Dimension 1', 'Dimension 2'])

display(pd.DataFrame(np.round(pca_samples, 4), columns = ['Dimension 1', 'Dimension 2']))

# Creating range for clusters 
range_n_clusters = list(range(2,11))

for n_clusters in range_n_clusters:
   
    clusterer = KMeans(n_clusters=n_clusters).fit(reduced_data)

    preds = clusterer.predict(reduced_data)

    centers = clusterer.cluster_centers_

    sample_preds = clusterer.predict(pca_samples)

    score = silhouette_score(reduced_data, preds, metric='euclidean')
    print ("For n_clusters = {}. The average silhouette_score is : {}".format(n_clusters, score))

log_centers = pca.inverse_transform(centers)

true_centers = np.exp(log_centers)

segments = ['Segment {}'.format(i) for i in range(0,len(centers))]
true_centers = pd.DataFrame(np.round(true_centers), columns = data.columns)
true_centers.index = segments
display(true_centers)

display(true_centers - data.median())

# Cluster's deviation from the mean
display(true_centers - data.mean())


for i, pred in enumerate(sample_preds):
    print ("Sample point", i, "predicted to be in Cluster", pred)


